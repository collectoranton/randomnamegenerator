﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;

namespace randomnamegenerator
{
    class TextAnalyzer
    {
        public void GetChunksFromText(int chunkLength, string pattern, string inputPath, string outputPath)
        {
            var streamReader = new StreamReader(inputPath);
            StringBuilder stringBuilder = new StringBuilder(chunkLength);
            var list = new List<string>();

            while (!streamReader.EndOfStream)
            {
                while (stringBuilder.Length != chunkLength && !streamReader.EndOfStream)
                {
                    var getCharacter = (char)streamReader.Read();
                    var buffer = getCharacter.ToString().ToLower();

                    if (pattern.Contains(buffer))
                        stringBuilder.Append(buffer);
                    else
                        stringBuilder.Clear();
                }

                if (!streamReader.EndOfStream)
                {
                    list.Add(stringBuilder.ToString());
                    stringBuilder.Remove(0, 1);
                }
            }

            streamReader.Close();
            WriteWordListToFile(list, outputPath);
        }

        void WriteWordListToFile(List<string> wordList, string path)
        {
            var streamWriter = new StreamWriter(path);

            foreach (var word in wordList)
                streamWriter.WriteLine(word);

            streamWriter.Close();
        }
    }
}
