﻿using System;
using System.Collections.Generic;
using System.IO;

namespace randomnamegenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            UI.Run();
        }
    }
}
